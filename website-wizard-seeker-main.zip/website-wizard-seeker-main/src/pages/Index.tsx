
import { useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  Zap,
  Server
} from "lucide-react";
import { Helmet } from "react-helmet";

export default function Index() {
  // Add schema.org structured data for local business
  const schemaData = {
    "@context": "https://schema.org",
    "@type": "Service",
    "name": "Chicago VPS Hosting",
    "description": "High-performance Virtual Private Servers with 99.9% uptime in the heart of Chicago",
    "provider": {
      "@type": "Organization",
      "name": "Chicago VPS Hosting",
      "url": "https://webhostingchicago.duoservers.com/"
    },
    "areaServed": {
      "@type": "City",
      "name": "Chicago"
    },
    "serviceType": "VPS Hosting"
  };

  return (
    <>
      <Helmet>
        <script type="application/ld+json">
          {JSON.stringify(schemaData)}
        </script>
      </Helmet>
      
      <div className="min-h-screen bg-gray-50">
        {/* Hero Section */}
        <section className="pt-20 pb-12 bg-gradient-to-b from-blue-900 via-blue-800 to-blue-700 text-white">
          <div className="container max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid md:grid-cols-2 gap-8 items-center"
            >
              <div>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  <h1 className="text-4xl md:text-5xl font-bold mb-4">
                    Chicago VPS Hosting
                  </h1>
                  <p className="text-xl text-blue-100 mb-8">
                    High-performance Virtual Private Servers with 99.9% uptime in the heart of Chicago
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <Button 
                      size="lg" 
                      className="bg-green-500 hover:bg-green-600"
                      onClick={() => window.location.href = "https://webhostingchicago.duoservers.com/"}
                      aria-label="Get started with Chicago VPS Hosting"
                    >
                      <Zap className="mr-2 h-5 w-5" aria-hidden="true" />
                      Get Started
                    </Button>
                  </div>
                </motion.div>
              </div>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 }}
                className="hidden md:block"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-blue-500 rounded-full opacity-20 blur-3xl" />
                  <div className="relative z-10">
                    <Server className="h-64 w-64 mx-auto text-white" aria-label="Server icon" />
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
}
